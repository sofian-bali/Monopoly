Commande pour executer les tests : 

```
./vendor/bin/phpunit --testdox
```

Commande pour sortir également le coverage au format HTML dans nu dossier "coverage" : 

```
./vendor/bin/phpunit --testdox --coverage-html ./coverage
```