<?php declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;

use App\Classes\Dices;

final class DicesTest extends TestCase {

    /*
        // test result
        // test roll
        // test is_double
    */

}