<?php 

namespace App\Config;

class Config {

    // banks
    public static $cash = 20580;
    public static $houses = 32;
    public static $hotels = 12;

}



