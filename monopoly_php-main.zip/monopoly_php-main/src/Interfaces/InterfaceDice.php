<?php

namespace App\Interfaces;

interface InterfaceDice {
    public function roll(): int;
}
